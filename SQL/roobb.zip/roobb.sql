-- phpMyAdmin SQL Dump
-- version 4.0.10.10
-- http://www.phpmyadmin.net
--
-- Хост: localhost
-- Время создания: Дек 12 2016 г., 15:01
-- Версия сервера: 5.5.44-0+deb7u1-log
-- Версия PHP: 5.4.45-0+deb7u2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `roobb`
--

-- --------------------------------------------------------

--
-- Структура таблицы `cat_news`
--

CREATE TABLE IF NOT EXISTS `cat_news` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Дамп данных таблицы `cat_news`
--

INSERT INTO `cat_news` (`id`, `title`) VALUES
(1, 'Спорт'),
(2, 'Культура'),
(3, 'Технологии'),
(4, 'Экономика');

-- --------------------------------------------------------

--
-- Структура таблицы `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `messages`
--

INSERT INTO `messages` (`id`, `name`, `email`, `message`) VALUES
(1, 'Test', 'test@test.com', 'Test message'),
(2, '3qe', '234@I.UA', 'EFWERWEW'),
(3, 'Фома', '45@ukr.net', 'werwrwerw');

-- --------------------------------------------------------

--
-- Структура таблицы `news`
--

CREATE TABLE IF NOT EXISTS `news` (
  `id` tinyint(3) unsigned NOT NULL AUTO_INCREMENT,
  `alias` varchar(100) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text,
  `is_published` tinyint(1) unsigned DEFAULT '0',
  `id_cat_news` tinyint(3) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Дамп данных таблицы `news`
--

INSERT INTO `news` (`id`, `alias`, `title`, `content`, `is_published`, `id_cat_news`) VALUES
(1, 'sport', 'Донецький «Шахтар» здобув шосту перемогу у Лізі Європи. Фоторепортаж', '', 1, 0),
(2, 'sport', 'Экс-президент ФИФА Блаттер раскритиковал нынешнего руководителя футбола', 'Здесь будет контент страницы Test Page', 1, 0),
(3, 'sport', 'Футболіст "Шахтаря" претендує на звання кращого гравця шостого туру Ліги Європи', '', 1, 0),
(4, 'sport', '"Шапекоэнсе" представил обновленную эмблему', '', 1, 0),
(5, 'sport', 'Моуриньо понравились украинские болельщики', '', 1, 0),
(6, 'sport', 'Прямая трансляция M-1 Challenge 73: Эмеев — Токов, Бухингер — Идрисов', '', 1, 0),
(7, 'sport', 'Стефан Решко оцінив вердикт КДК по перенесених матчах', '', 1, 0),
(8, 'sport', 'Чемпионат Украины гроссмейстер Каменского завершила с призовым серебром', '', 1, 0),
(9, 'cultura', 'Киевские кондитеры испекут шоколадного Хосе Каррераса', '', 1, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` smallint(5) unsigned NOT NULL AUTO_INCREMENT,
  `login` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `role` varchar(45) NOT NULL DEFAULT 'admin',
  `password` char(32) NOT NULL,
  `is_active` tinyint(1) unsigned DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `email`, `role`, `password`, `is_active`) VALUES
(1, 'admin', 'admin@your-site.com', 'admin', '44ca5fa5c67e434b9e779c5febc46f06', 1),
(2, 'roobb', '1@example.com', 'admin', '1', 1);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
